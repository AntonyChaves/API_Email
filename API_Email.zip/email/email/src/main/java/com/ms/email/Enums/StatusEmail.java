package com.ms.email.Enums;

public enum StatusEmail {

    SENT,
    ERROR;
}
