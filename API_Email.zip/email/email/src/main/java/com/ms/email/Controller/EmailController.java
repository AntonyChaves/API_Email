package com.ms.email.Controller;

import com.ms.email.DTOS.EmailDto;
import com.ms.email.Model.EmailModel;
import com.ms.email.Service.EmailService;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.logging.LogManager;
import java.util.logging.Logger;

@RestController()
public class EmailController {

    Logger logger = LogManager.getLogger(EmailController.class);

    @Autowired
    EmailService emailService;

    @PostMapping(value = "/sending-email")
    public ResponseEntity <EmailModel> sendingEmail(@RequestBody @Valid EmailDto emailDto)
    {
        EmailModel email = new EmailModel();
        BeanUtils.copyProperties(emailDto, email);
        emailService.sendEmail(email);
        return new ResponseEntity<>(email, HttpStatus.CREATED);
    }


}
